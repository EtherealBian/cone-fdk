"""Predeclared paired benchmark on both real pine conditions. No claim of dimensional truth or isolated kernel speed."""
import json,os,sys,math,fcntl,datetime,tempfile
from contextlib import ExitStack
from pathlib import Path
from statistics import median
import qualify_pine as q
w=Path.cwd();m=w.parent;src=m/'pine-scans-001';parent=m/'pine-gb10-001';build=w/'build/spark';dest=m/'pine-budget-pairs-001';dest.mkdir(exist_ok=False);need=q.need;sha=q.sha;pp='250443f4c5ddd9cb3458617a072b7f1c4d9c40b539e3bffaeb73f4d1b9ece740';sp='2417f08c8a91a95b061acfe1aa2126932b6882f8bd75673e65df261d2738a43b';order=[]
for block in range(-1,6):
 names=('pine90','pine720') if block%2==0 else ('pine720','pine90')
 for name in names:
  budgets=(64,384) if (block+(name=='pine720'))%2==0 else (384,64)
  for budget in budgets:order.append((block,name,budget))
protocol=dict(format='CFDK-pine-budget-pairs-pilot-v1',parent_sha256=pp,scan_sha256=sp,driver_sha256=sha(Path(__file__)),order=order,primary='native process seconds, includes startup and native file output; no external fsync; excludes sealing/digest',comparison='64 versus 384 MiB requested native-owned GPU budget only, batch 16 unchanged, full 256 cubed at 44 mm field. Block -1 warmup excluded; six measured adjacent AB/BA pairs per view count. No speed threshold; no extrapolation to other computers or dimensions.',expected='each output identical to frozen native volume; both original ASTRA volume hashes checked, no ASTRA rerun during timing')
def dump(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
dump(dest/'protocol.json',protocol);parent_doc=q.checked(parent/'qualification.json',pp,65536);proto,scan=q.provenance(src,sp,w/'data/pine-cone-originals/source-receipt.json');rec=q.checked(build/'build.json',q.BUILD_PIN,65536);need(parent_doc['scan_receipt_sha256']==sp and parent_doc['build_sha256']==q.BUILD_PIN and q.sha(Path(q.__file__))==parent_doc['script_sha256'] and sha(w/'scripts/common.py')==parent_doc['independent_code_sha256'],'changed parent or runner'); rows=[]
with (m/'gpu.lock').open('rb') as lk, tempfile.TemporaryDirectory(dir=dest,prefix='bind-') as temp, ExitStack() as stack:
 fcntl.flock(lk,fcntl.LOCK_EX);bound={}
 for name in ('pine90','pine720'):
  row=scan['scans'][name];p=parent_doc['scans'][name];need(row['projections_sha256']==p['projections_sha256'] and row['geom_sha256']==p['geometry_sha256'] and p['native_vs_astra']['rel_l2']<.002,'source mismatch');
  for leaf,key in [('native-0.f32','dense_sha256'),('astra.f32','astra_sha256')]:need(sha(parent/name/leaf)==p[key],'original oracle mismatch')
  b=Path(temp)/name;b.mkdir();bound[name]=(stack.enter_context(q.inputs(src,build,row,name,b,rec['products'])),b)
 for i,(block,name,budget) in enumerate(order):
  st=scan['scans'][name];p=parent_doc['scans'][name];s,b=bound[name];out=dest/f'trial-{i:02d}.f32';run=q.reconstruct(s,out,256,44.,budget,16,build=b); q.guards(run,256,st['views'],44.,budget,16,[0,0,0,256,256,256],st['projection_bytes']);digest=sha(out);need(out.stat().st_size==256**3*4 and digest==p['dense_sha256'] and run['projection_passes']==run['slabs'] and run['filter_batches']==math.ceil(st['views']/16)*run['projection_passes'] and math.isfinite(run['process_seconds']) and run['process_seconds']>0,'run drift'); d=dict(block=block,case=name,budget_mib=budget,sha256=digest,run=run);row_file=dest/f'trial-{i:02d}.json';dump(row_file,d);rows.append(d);keep=parent/name/'native-0.f32';need(sha(keep)==digest and sha(out)==digest,'repeat changed before retirement');size=out.stat().st_size;out.unlink();
  with (m/'maintenance/spark-cleanup.jsonl').open('a') as f: print(json.dumps(dict(host='DGX Spark',time=datetime.datetime.now().astimezone().isoformat(),path=str(out),reason='closed paired trial; output rehashed against pinned parent and retained identical native oracle',logical_bytes=size,retained=str(keep),receipt=str(row_file))),file=f)
 for name in ('pine90','pine720'):
  ds=[[r for r in rows if r['block']==i and r['case']==name] for i in range(6)];assert all(len(pair)==2 for pair in ds)
 print('Qualified rows',len(rows),flush=True);dump(dest/'result.json',dict(protocol_sha256=sha(dest/'protocol.json'),row_sha256=[sha(dest/f'trial-{i:02d}.json') for i in range(len(rows))],measured_pairs_per_condition=6,scope=protocol['comparison']))
